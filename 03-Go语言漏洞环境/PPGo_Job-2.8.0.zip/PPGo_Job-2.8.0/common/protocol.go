/************************************************************
** @Description: protol
** @Author: george hao
** @Date:   2019-06-27 15:33
** @Last Modified by:  george hao
** @Last Modified time: 2019-06-27 15:33
*************************************************************/
package common

type RpcResult struct {
	Status  int
	Message string
}
