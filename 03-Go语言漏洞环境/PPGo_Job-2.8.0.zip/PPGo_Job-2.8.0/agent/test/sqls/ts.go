/************************************************************
** @Description: ts
** @Author: george hao
** @Date:   2019-07-04 17:23
** @Last Modified by:  george hao
** @Last Modified time: 2019-07-04 17:23
*************************************************************/
package main

import "github.com/george518/PPGo_Job/models"

func main() {

	models.TaskTotalRunNum()
}
