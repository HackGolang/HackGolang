package hashalgo
